'''
Call the final pipeline on the test data here. This should import the pipeline file for that purpose.
'''