'''
This is an example feature extraction file for a feature called 'OneHot'. It should have functions that take data preprocessed
by the Data Preperation (e.g., x_train, x_val,..) stage and return such data in feature form that could be used by ML algorithms.
'''