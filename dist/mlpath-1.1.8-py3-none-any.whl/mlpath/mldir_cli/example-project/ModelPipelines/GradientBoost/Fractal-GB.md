<table>
<tr>
<th colspan=4 style="text-align: center; vertical-align: middle;">info</th>
<th colspan=2 style="text-align: center; vertical-align: middle;">apply_SFTA_d</th>
<th colspan=4 style="text-align: center; vertical-align: middle;">GradientBoostingClassifier</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">metrics</th>
</tr>
<th style="text-align: center; vertical-align: middle;">time</th>
<th style="text-align: center; vertical-align: middle;">date</th>
<th style="text-align: center; vertical-align: middle;">duration</th>
<th style="text-align: center; vertical-align: middle;">id</th>
<th style="text-align: center; vertical-align: middle;">deviation</th>
<th style="text-align: center; vertical-align: middle;">saved</th>
<th style="text-align: center; vertical-align: middle;">n_estimators</th>
<th style="text-align: center; vertical-align: middle;">learning_rate</th>
<th style="text-align: center; vertical-align: middle;">max_depth</th>
<th style="text-align: center; vertical-align: middle;">random_state</th>
<th style="text-align: center; vertical-align: middle;">accuracy</th>
</tr>
<tr>
<td style="text-align: center; vertical-align: middle;"> <font color=white>22:19:27</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>08/12/23</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1.58 s</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>20</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>False</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>50</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>3</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.5</font></td>
</tr>
