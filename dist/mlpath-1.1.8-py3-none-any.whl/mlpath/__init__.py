"""Entry point for the mlpath package."""
from mlpath.mlquest.mlquest import mlquest
from mlpath.mldir_cli.cli import main