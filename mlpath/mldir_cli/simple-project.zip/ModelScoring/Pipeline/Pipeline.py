'''
This file should load one of the saved models (the best one) and use it to build a production pipeline (like the 
one in the corresponding notebook) in the form of a function that takes a data item as an input and returns a 
prediction as an output.
'''