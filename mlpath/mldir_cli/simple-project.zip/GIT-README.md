
# MLDir Guide
This project...

## Datasets & Preprocessing 📊
Training...

## Features Extracted 🗿
Features considered... 

## Models Considered 🤖
Models selected...

## Metrics & Results 📉
The metric...

## Running the Project 🚀
Start by

## Collaborators

<!-- readme: contributors -start -->

<!-- readme: contributors -end -->