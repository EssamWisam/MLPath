<table>
<tr>
<th colspan=4 style="text-align: center; vertical-align: middle;">info</th>
<th colspan=6 style="text-align: center; vertical-align: middle;">ConvNet</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">Adam</th>
<th colspan=5 style="text-align: center; vertical-align: middle;">train_model</th>
<th colspan=2 style="text-align: center; vertical-align: middle;">metrics</th>
</tr>
<th style="text-align: center; vertical-align: middle;">time</th>
<th style="text-align: center; vertical-align: middle;">date</th>
<th style="text-align: center; vertical-align: middle;">duration</th>
<th style="text-align: center; vertical-align: middle;">id</th>
<th style="text-align: center; vertical-align: middle;">hidden_size</th>
<th style="text-align: center; vertical-align: middle;">output_size</th>
<th style="text-align: center; vertical-align: middle;">kernel_dim</th>
<th style="text-align: center; vertical-align: middle;">in_channels</th>
<th style="text-align: center; vertical-align: middle;">mid_channels</th>
<th style="text-align: center; vertical-align: middle;">out_channels</th>
<th style="text-align: center; vertical-align: middle;">lr</th>
<th style="text-align: center; vertical-align: middle;">model</th>
<th style="text-align: center; vertical-align: middle;">num_epochs</th>
<th style="text-align: center; vertical-align: middle;">criterion</th>
<th style="text-align: center; vertical-align: middle;">optimizer</th>
<th style="text-align: center; vertical-align: middle;">device</th>
<th style="text-align: center; vertical-align: middle;">accuracy</th>
<th style="text-align: center; vertical-align: middle;">rand_accurary</th>
</tr>
<tr>
<td style="text-align: center; vertical-align: middle;"> <font color=white>17:52:43</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>04/20/23</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>26.53 s</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>80</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>2</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>10</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>12</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>16</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.001</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>ConvNet(
  (feature_extraction): Sequential(
    (0): Conv2d...</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>12</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>CrossEntropyLoss()</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>Adam (
Parameter Group 0
    amsgrad: False
    betas: (0.9,...</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>cpu</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.0</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>50.0</font></td>
</tr>
