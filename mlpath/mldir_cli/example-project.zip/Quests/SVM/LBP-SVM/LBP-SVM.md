<table>
<tr>
<th colspan=4 style="text-align: center; vertical-align: middle;">info</th>
<th colspan=2 style="text-align: center; vertical-align: middle;">apply_LBP_d</th>
<th colspan=4 style="text-align: center; vertical-align: middle;">SVC</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">metrics</th>
</tr>
<th style="text-align: center; vertical-align: middle;">time</th>
<th style="text-align: center; vertical-align: middle;">date</th>
<th style="text-align: center; vertical-align: middle;">duration</th>
<th style="text-align: center; vertical-align: middle;">id</th>
<th style="text-align: center; vertical-align: middle;">P</th>
<th style="text-align: center; vertical-align: middle;">R</th>
<th style="text-align: center; vertical-align: middle;">kernel</th>
<th style="text-align: center; vertical-align: middle;">C</th>
<th style="text-align: center; vertical-align: middle;">gamma</th>
<th style="text-align: center; vertical-align: middle;">degree</th>
<th style="text-align: center; vertical-align: middle;">Micro_F1</th>
</tr>
<tr>
<td style="text-align: center; vertical-align: middle;"> <font color=white>17:51:59</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>04/20/23</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>3.93 min</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>12</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>3</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>linear</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>12.2</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.01</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>3</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.0</font></td>
</tr>
