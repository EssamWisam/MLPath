<table>
<tr>
<th colspan=4 style="text-align: center; vertical-align: middle;">info</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">apply_rand_d</th>
<th colspan=4 style="text-align: center; vertical-align: middle;">SVC</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">metrics</th>
</tr>
<th style="text-align: center; vertical-align: middle;">time</th>
<th style="text-align: center; vertical-align: middle;">date</th>
<th style="text-align: center; vertical-align: middle;">duration</th>
<th style="text-align: center; vertical-align: middle;">id</th>
<th style="text-align: center; vertical-align: middle;">num_samples</th>
<th style="text-align: center; vertical-align: middle;">kernel</th>
<th style="text-align: center; vertical-align: middle;">C</th>
<th style="text-align: center; vertical-align: middle;">gamma</th>
<th style="text-align: center; vertical-align: middle;">degree</th>
<th style="text-align: center; vertical-align: middle;">F1</th>
</tr>
<tr>
<td style="text-align: center; vertical-align: middle;"> <font color=white>17:52:04</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>04/20/23</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>3.94 min</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>99</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>rbf</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>9.2</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.001</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>3</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.0</font></td>
</tr>
