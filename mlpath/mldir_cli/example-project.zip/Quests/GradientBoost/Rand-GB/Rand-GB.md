<table>
<tr>
<th colspan=4 style="text-align: center; vertical-align: middle;">info</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">apply_rand_d</th>
<th colspan=4 style="text-align: center; vertical-align: middle;">GradientBoostingClassifier</th>
<th colspan=1 style="text-align: center; vertical-align: middle;">metrics</th>
</tr>
<th style="text-align: center; vertical-align: middle;">time</th>
<th style="text-align: center; vertical-align: middle;">date</th>
<th style="text-align: center; vertical-align: middle;">duration</th>
<th style="text-align: center; vertical-align: middle;">id</th>
<th style="text-align: center; vertical-align: middle;">num_samples</th>
<th style="text-align: center; vertical-align: middle;">n_estimators</th>
<th style="text-align: center; vertical-align: middle;">learning_rate</th>
<th style="text-align: center; vertical-align: middle;">max_depth</th>
<th style="text-align: center; vertical-align: middle;">random_state</th>
<th style="text-align: center; vertical-align: middle;">accuracy</th>
</tr>
<tr>
<td style="text-align: center; vertical-align: middle;"> <font color=white>17:51:13</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>04/20/23</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>4.66 min</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>1</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>99</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>99</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>30</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>6</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0</font></td>
<td style="text-align: center; vertical-align: middle;"> <font color=white>0.5</font></td>
</tr>
